package com.example.aplikasi_pemesanan_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
